/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdc_assignment2_sem2;

import java.util.List;
import java.util.Arrays;


/**
 *
 * @author damnd
 */

// Class used to implement Hindi vocab
public class HindiQuiz extends Quiz 
{
    public HindiQuiz(VocabApp appGUI) 
    {
        super(appGUI);
    }

    @Override
    public void startQuiz() 
    {
        GuiSetup();
        loadNextQuestion();
    }

    // Method used to start language quiz (same for every language)
    @Override
    protected String getLanguageName() 
    {
        return "Hindi";
    }

    // All words for language
    @Override
    protected List<Vocab> getVocab() 
    {
        return Arrays.asList(
            new Vocab("Namaste", "Hello"),
            new Vocab("Dhanyavaad", "Thank you"),
            new Vocab("Paanee", "Water"),
            new Vocab("Aap kaise hain?", "How are you?"),
            new Vocab("Namaste, aap kaise hain?", "Hello, how are you?")    
        );
    }
}
