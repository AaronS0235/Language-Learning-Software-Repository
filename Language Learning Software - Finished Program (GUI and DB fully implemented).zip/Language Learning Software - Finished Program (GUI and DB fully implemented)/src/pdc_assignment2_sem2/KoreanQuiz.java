/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdc_assignment2_sem2;

import java.util.Arrays;
import java.util.List;


/**
 *
 * @author damnd
 */

// Class used to implement Korean Vocab
public class KoreanQuiz extends Quiz 
{
    public KoreanQuiz(VocabApp appGUI) 
    {
        super(appGUI);
    }

    // Method used to start language quiz (same for every language)
    @Override
    public void startQuiz() 
    {
        GuiSetup();
        loadNextQuestion();
    }

    @Override
    protected String getLanguageName() 
    {
        return "Korean";
    }

    
    // All words for language
    @Override
    protected List<Vocab> getVocab() 
    {
        return Arrays.asList(
            new Vocab("Annyeonghaseyo", "Hello"),
            new Vocab("Gamsahabnida", "Thank you"),
            new Vocab("Mul", "Water"),
            new Vocab("Eotteohge jinaeseyo?", "How are you?"), 
            new Vocab("Annyeonghaseyo, eotteohge jinaeseyo?", "Hello, how are you?")    
        );
    }
}



