/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdc_assignment2_sem2;

import java.util.Arrays;
import java.util.List;


/**
 *
 * @author damnd
 */

// Class used to implement Spanish Vocab
public class SpanishQuiz extends Quiz 
{
    public SpanishQuiz(VocabApp appGUI) 
    {
        super(appGUI);
    }

    // Method used to start language quiz (same for every language)
    @Override
    public void startQuiz() 
    {
        GuiSetup();
        loadNextQuestion();
    }

    @Override
    protected String getLanguageName() 
    {
        return "Spanish";
    }

    
    // All words for language
    @Override
    protected List<Vocab> getVocab() 
    {
        return Arrays.asList(
            new Vocab("Hola", "Hello"),
            new Vocab("Gracias", "Thank you"),
            new Vocab("Agua", "Water"),
            new Vocab("Cómo estás?", "How are you?"),
            new Vocab("Hola, Cómo estás?", "Hello, how are you?")    
        );
    }
}




