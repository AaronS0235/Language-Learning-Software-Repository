/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdc_assignment2_sem2;

/**
 *
 * @author damnd
 */

// imports
import javax.swing.*;
import java.sql.*;

public class VocabApp extends JFrame 
{
     // Main method
    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(() -> 
        {
            // main application window
            VocabApp app = new VocabApp();
            app.showApp();
        });
    }
     
    private Connection connection;

    public VocabApp() 
    {
        // Set up the main application window
        setTitle("Language Learning App");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Method called to
        // connect to the database
        DatabaseConnect();

        // Program starts off with login screen by calling method
        LoginScreen();
    }

    
    // Method used to connect to database
    private void DatabaseConnect() 
    {
        try 
        {
            String url = "jdbc:derby://localhost:1527/LanguageLearningSoftwareDB";
            String user = "LLSDB"; 
            String password = "AHPDC2";
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Database connected successfully.");
        }
        catch (SQLException e) 
        {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to connect to the database.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method used to control login screen
    private void LoginScreen() 
    {
        getContentPane().removeAll();
        setTitle("Login");

        // Username label and text field
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(50, 50, 100, 30);
        add(usernameLabel);

        JTextField usernameField = new JTextField();
        usernameField.setBounds(150, 50, 150, 30);
        add(usernameField);

        // Password label and text field
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 90, 100, 30);
        add(passwordLabel);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(150, 90, 150, 30);
        add(passwordField);

        // Login button to allow the user to login
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(80, 150, 100, 30);
        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            // Validation
            // Authenticate() method called
            if (authenticate(username, password)) 
            {
                // if login is successfull main menu method is called to
                // display the main menu of the program
                showMainMenu();
            } 
            else 
            {
                // If login is unsuccessful, user is prompted with message
                JOptionPane.showMessageDialog(this, "Invalid credentials. Please try again.");
            }
        });
        add(loginButton);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(200, 150, 100, 30);
        registerButton.addActionListener(e -> showRegistrationScreen());
        add(registerButton);

        setVisible(true);
        repaint();
    }

    
    // Method used to authenticate user login credentials
    // If login credentials are not found in DB, then login is rejected
    // and user is prompted with a message informing them that invalid
    // login credentials have been used
    private boolean authenticate(String username, String password) 
    {
        try 
        {
            String query = "SELECT * FROM DBUSERS WHERE USERNAME = ? AND PASSWORD = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next();
        }
        catch (SQLException e) 
        {
            e.printStackTrace();
            return false;
        }
    }

    
    // Method to control registration screen
    private void showRegistrationScreen() 
    {
        // Set title of register panel
        getContentPane().removeAll();
        setTitle("Register");

        // Username label
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(50, 50, 100, 30);
        add(usernameLabel);

        // Text box for user to enter username
        JTextField usernameField = new JTextField();
        usernameField.setBounds(150, 50, 150, 30);
        add(usernameField);

        // Password label
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 90, 100, 30);
        add(passwordLabel);

        // Text box for user to enter password
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(150, 90, 150, 30);
        add(passwordField);

        // Button used to register details to DB once entered
        JButton registerButton = new JButton("Register");
        registerButton.setBounds(150, 150, 100, 30);
        registerButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            registerUser(username, password);
            JOptionPane.showMessageDialog(this, "Registration successful! Please login.");
            LoginScreen();
        });
        add(registerButton);

        setVisible(true);
        repaint();
    }

    
    
    // Method used to register user to DB once user has entered their desiered login details
    private void registerUser(String username, String password) 
    {
        try {
            String query = "INSERT INTO DBUSERS (USERNAME, PASSWORD) VALUES (?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);
            statement.executeUpdate();
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }

    
    // Method used to set up main menu
    private void showMainMenu() 
    {
        // Main menu title
        getContentPane().removeAll();
        setTitle("Main Menu");

        
        // Quiz selection prompt
        JLabel selectQuizLabel = new JLabel("Select a Quiz:");
        selectQuizLabel.setBounds(140, 30, 200, 30);
        add(selectQuizLabel);

        
        // Hindi Quiz
        // Setting up button to select Hindi Quiz
        JButton hindiQuizButton = new JButton("Hindi Quiz");
        hindiQuizButton.setBounds(140, 70, 120, 30);
        hindiQuizButton.addActionListener(e -> 
        {
            new HindiQuiz(this).startQuiz();
            setVisible(false); 
        });
        add(hindiQuizButton);

        
        // Korean Quiz
        // Setting up Korean Quiz button
        JButton koreanQuizButton = new JButton("Korean Quiz");
        koreanQuizButton.setBounds(140, 110, 120, 30);
        koreanQuizButton.addActionListener(e -> {
            new KoreanQuiz(this).startQuiz();
            setVisible(false);
        });
        add(koreanQuizButton);

        // Spanish Quiz
        // Setting up button for Spanish Quiz
        JButton spanishQuizButton = new JButton("Spanish Quiz");
        spanishQuizButton.setBounds(140, 150, 120, 30);
        spanishQuizButton.addActionListener(e -> {
            new SpanishQuiz(this).startQuiz();
            setVisible(false);
        });
        add(spanishQuizButton);

        
        // Setting up button which will allow the user to logout
        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(140, 190, 120, 30);
        logoutButton.addActionListener(e -> LoginScreen());
        add(logoutButton);

        setVisible(true);
        repaint();
    }

    
    // DB connection getter
    public Connection getConnection() 
    {
        return connection;
    }

    
    // Main window
    public void showApp() 
    {
        // Display main window
        setVisible(true); 
    }
}





