/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdc_assignment2_sem2;

/**
 *
 * @author damnd
 */
public class Vocab 
{
    // Word to be translated/learned
    private String foreignWord;
    
    // Translation variable
    private String englishTranslation;

    // Constructor
    public Vocab(String foreignWord, String englishTranslation) 
    {
        this.foreignWord = foreignWord;
        this.englishTranslation = englishTranslation;
    }

    // Getters
    public String getForeignWord() 
    {
        return foreignWord;
    }

    public String getEnglishTranslation() 
    {
        return englishTranslation;
    }
}





