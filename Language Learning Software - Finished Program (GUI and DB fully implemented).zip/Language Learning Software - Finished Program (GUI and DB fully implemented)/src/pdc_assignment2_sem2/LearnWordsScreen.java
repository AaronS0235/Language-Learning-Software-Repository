/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdc_assignment2_sem2;

/**
 *
 * @author damnd
 */
// Imports
import javax.swing.*;
import java.util.List;

// Class handles vocabulary words for learning
public class LearnWordsScreen 
{
    private List<Vocab> hindiVocab, koreanVocab, spanishVocab;

    // Constructor
    public LearnWordsScreen(List<Vocab> hindi, List<Vocab> korean, List<Vocab> spanish) 
    {
        this.hindiVocab = hindi;
        this.koreanVocab = korean;
        this.spanishVocab = spanish;
    }

    // Sets up GUI for vocabulary list screen
    public void show() 
    {
        JFrame frame = new JFrame("Learn Vocabulary Words");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 300);
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        StringBuilder vocabList = new StringBuilder();
        vocabList.append("Hindi Vocabulary:\n");
        for (Vocab item : hindiVocab) 
        {
            vocabList.append(item.getForeignWord()).append(" - ").append(item.getEnglishTranslation()).append("\n");
        }
        vocabList.append("\nKorean Vocabulary:\n");
        for (Vocab item : koreanVocab) 
        {
            vocabList.append(item.getForeignWord()).append(" - ").append(item.getEnglishTranslation()).append("\n");
        }
        vocabList.append("\nSpanish Vocabulary:\n");
        for (Vocab item : spanishVocab) 
        {
            vocabList.append(item.getForeignWord()).append(" - ").append(item.getEnglishTranslation()).append("\n");
        }

        textArea.setText(vocabList.toString());
        frame.add(new JScrollPane(textArea));
        frame.setVisible(true);
    }
}

