/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdc_assignment2_sem2;

/**
 *
 * @author damnd
 */
// Imports
import java.util.List;
import javax.swing.*;

// Abstract class Quiz
abstract class Quiz 
{
    // Users score
    protected int score;
    
    // Tracks current question number
    protected int currentQuestionIndex;
    
    // GUI Frame
    protected JFrame frame;
    
    // Answer Field
    protected JTextField answerField;
    
    // Label used to display questions
    protected JLabel questionLabel;
    
    // Reference to the main app
    protected VocabApp appGUI;

    
    // Constructor
    public Quiz(VocabApp appGUI) 
    {
        this.score = 0;
        this.currentQuestionIndex = 0;
        this.appGUI = appGUI;
    }

    
    // abstract method to start quiz + get language name
    public abstract void startQuiz();
    protected abstract String getLanguageName();

    
    // Sets up GUI components for the quiz
    protected void GuiSetup() 
    {
        frame = new JFrame(getLanguageName() + " Quiz");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 250);
        frame.setLayout(null);

        // Displays current question
        questionLabel = new JLabel();
        questionLabel.setBounds(50, 30, 300, 30);
        frame.add(questionLabel);

        // Text field used for user input
        answerField = new JTextField();
        answerField.setBounds(50, 70, 200, 30);
        frame.add(answerField);

        // Submit button created so user can
        // Submit answer
        JButton submitButton = new JButton("Submit");
        submitButton.setBounds(250, 70, 100, 30);
        submitButton.addActionListener(e -> checkAnswer());
        frame.add(submitButton);

        // Button used to display full vocabulary of a language
        // so user can learn phrases and prepare for quiz
        JButton learnWordsButton = new JButton("Learn Words");
        learnWordsButton.setBounds(50, 120, 150, 30);
        learnWordsButton.addActionListener(e -> showWords());
        frame.add(learnWordsButton);

        // Button to return to main menu
        JButton backButton = new JButton("Back to Menu");
        backButton.setBounds(210, 120, 150, 30);
        backButton.addActionListener(e -> 
        {
            frame.dispose();
            appGUI.showApp();
        });
        frame.add(backButton);

        frame.setVisible(true);
    }

    //method to get vocab list
    protected abstract List<Vocab> getVocab();

    
    // Method used to load next question in quiz
    protected void loadNextQuestion() {
        if (currentQuestionIndex < getVocab().size()) 
        {
            Vocab item = getVocab().get(currentQuestionIndex);
            questionLabel.setText("Translate to English: " + item.getForeignWord());
            answerField.setText("");
        } else 
        {
            showScore();
            frame.dispose();
            appGUI.showApp();
        }
    }

    
    // Method used to check if users answer is correct
    protected void checkAnswer() 
    {
        String answer = answerField.getText().trim();
        Vocab item = getVocab().get(currentQuestionIndex);

        if (answer.equalsIgnoreCase(item.getEnglishTranslation())) 
        {
            score++;
            JOptionPane.showMessageDialog(frame, "Correct!");
        } 
        else 
        {
            JOptionPane.showMessageDialog(frame, "Wrong! Correct answer: " + item.getEnglishTranslation());
        }
        // question index incremented
        currentQuestionIndex++;
        // Method called to load next question
        loadNextQuestion();
    }

    
    // Method used to show users final score at the end of the quiz
    protected void showScore() 
    {
        JOptionPane.showMessageDialog(frame, "Your score: " + score);
    }

    
    // Method used to show all words in a certain language should the user click the
    // "Learn vocabulary button"
    protected void showWords() 
    {
        StringBuilder words = new StringBuilder("Words in this quiz:\n");
        for (Vocab item : getVocab()) 
        {
            words.append(item.getForeignWord()).append(" - ").append(item.getEnglishTranslation()).append("\n");
        }
        JOptionPane.showMessageDialog(frame, words.toString());
    }
}